package com.example.classroom.uno;

/**
 * Created by Classroom on 2/10/2018.
 */

public class Card {
    int color;
    String cardNum;

    public Card(int color, String cardNum){
        this.color = color;
        this.cardNum = cardNum;

    }

    public int getColor() {
        return color;
    }

    public String getCardNum() {
        return cardNum;
    }
}
