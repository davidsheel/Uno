package com.example.classroom.uno;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.Stack;

public class UnoMain extends AppCompatActivity {
    int red = Color.parseColor("#E53935");
    int green = Color.parseColor("#43A047");
    int yellow = Color.parseColor("#FDDA35");
    int blue = Color.parseColor("#039BE5");
    int[] colors = {red, green, yellow, blue};
    ArrayList<Button> orderedCards = new ArrayList<Button>();
    Stack<Button> stack = new Stack<Button>();
    LinearLayout hand;
    Button cardInPlay;
    HashSet<Integer> hs = new HashSet<Integer>();
    Random rand = new Random();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uno_main);


        hand = findViewById(R.id.playerHand);
        cardInPlay = findViewById(R.id.playStack);
        createCards();
        cardInPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getNextCard();
            }
        });

    }



    public void createCards() {
        for (int i = 0; i < colors.length; i++) {
            for (int j = 1; j < 10; j++) {
                Card cardTag = new Card(colors[i], String.valueOf(j));
                final Button card = new Button(UnoMain.this);
                card.setText(String.valueOf(j));
                card.setBackgroundColor(colors[i]);
                card.setTag(cardTag);
                orderedCards.add(card);



                card.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                       getNextCard();

                    }
                });
            } ;

        }


        for(int i = 0; i <orderedCards.size(); i++){
            int index = rand.nextInt(orderedCards.size());
            while(hs.contains(index)){
                index = rand.nextInt(orderedCards.size());
            }
            stack.push(orderedCards.get(index));
            hs.add(index);
        }

        Card tempCard =(Card)stack.peek().getTag();
        cardInPlay.setBackgroundColor(tempCard.getColor());
        cardInPlay.setText(tempCard.getCardNum());

    }
        public void getNextCard(){
            hand.addView(stack.pop());
            Card tempCard =(Card)stack.peek().getTag();
            cardInPlay.setBackgroundColor(tempCard.getColor());
            cardInPlay.setText(tempCard.getCardNum());
        }

}
